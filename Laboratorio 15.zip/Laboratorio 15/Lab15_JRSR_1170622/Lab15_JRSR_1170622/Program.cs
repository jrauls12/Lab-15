﻿using System;

namespace Lab15_JRSR_1170622
{
    class Program
    {
        static void Main(string[] args)
        {
            string opcion;
            Console.WriteLine("BIENVENIDO AL MENU DE OPCIONES");
            Console.WriteLine("sELECCIONA QUE PCION NECESITAS");
            Console.WriteLine("1:NOMBRES Y EDAD");
            Console.WriteLine("2: NOMBRES Y NOTA");
            Console.WriteLine("3: SALIR");
            opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":
                    string[] nom = new string[5];
                    double[] edad = new double[5];
                    
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Ingrese los nombres de la spersonas");
                        nom[i] = Console.ReadLine();
                        Console.WriteLine("Ingrese la edad de las personas");
                        edad[i] = int.Parse(Console.ReadLine());
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("el nombre es  " + nom[i] + " tiene la edad de " + edad[i]);
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        if (edad[i] >= 18)
                        {
                            Console.WriteLine("las perosnas con mayor edad son " + nom[i] + " con " + edad[i]);
                        }else
                        {
                            Console.WriteLine("la persona " + nom[i] + " es menor de edad con " + edad[i]);
                        }
                    }
                    double promedio = 0;
                    double suma = 0;
                    for (int i = 0; i < 5; i++)
                    {
                        suma = suma + edad[i];
                    }

                    promedio = suma / 5;
                    Console.WriteLine("El promedio de edades es " + promedio);

                    break;
                case "2":
                    string[] nomap= new string[5];
                    double[] nota = new double[5];

                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Ingrese los nombres y apellidos de las perosnas");
                        nomap[i] = Console.ReadLine();
                        Console.WriteLine("Ingrese las noas de las personas");
                        nota[i] = double.Parse(Console.ReadLine());
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        if (nota[i] > nota[i])
                        {
                            Console.WriteLine("La persona " + nomap[i] + " tiene la mayor nota en la materia, su nota es de  " + nota[i]);
                        }
                        else if (nota[i] < nota[i])
                        {
                            Console.WriteLine("la persona " + nomap[i] + " tiene la nota mas baja de la materia con" + nota[i]+" de nota");
                        }
                    }

                    for (int i = 0; i < 5; i++)
                    {
                        if (nota[i] >= 71)
                        {
                            Console.WriteLine("la persona" + nomap[i] + " paso la clase con la nota de " + nota[i]);
                        }
                        else
                        {
                            Console.WriteLine("la persona " + nomap[i] + " perdio la clase con la nota de" + nota[i]);
                        }
                    }

                    double promedio2 = 0;
                    double suma2= 0;
                    for (int i = 0; i < 5; i++)
                    {
                        suma2 = suma2 + nota[i];
                    }

                    promedio2 = suma2 / 5;
                    Console.WriteLine("El promedio de edades es " + promedio2);
                    break;

                case "3":
                    Console.WriteLine("Saldra del programa");
                    Environment.Exit(0);
                    break;
            }
        }
    }
}
